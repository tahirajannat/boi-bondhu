// import bcrypt from "bcrypt";
// const saltRounds = 10;
// const myPlaintextPassword = "s0//P4$$w0rD";
// const someOtherPlaintextPassword = "not_bacon";
// export function passwordEncryption(e) {
//   console.log(`💩 ~ file: passwordEncryption.js ~ line 3 ~ hashPass ~ e`, e);

//   bcrypt.genSalt(saltRounds, function (err, salt) {
//     bcrypt.hash(myPlaintextPassword, salt, function (err, hash) {
//       // Store hash in your password DB.
//     });
//   });

//   return "abc";
// }

// export function passwordDecryption(e) {
//   console.log(`💩 ~ file: passwordEncryption.js ~ line 3 ~ hashPass ~ e`, e);
//   return "dec";
// }
